Initially prepared for the Esolang reverse-engineering
contest (2020). Fell free to contact me at kspalaiologos@gmail.com

The rules:
 * You get to see two interpreters for the x86 platform.
 * They have been obfuscated using a private obfuscator.
 * The first one was built for for speed, the second one for size.
 * The goal is to understand the underlying language these
  two programs execute.
 * A valid submission is an ISA description and a couple of programs
  to prove your understanding of the ISA. It can be a cat, hello world,
  fizzbuzz, or whatever else.

*** COPYRIGHT (C) PALAIOLOGOS @ MENACE
HAVE FUN! FEEL FREE TO REDISTRIBUTE, BUT
MAKE SURE YOU'RE SENDING OVER THE ENTIRE
ARCHIVE.